// Copyright Epic Games, Inc. All Rights Reserved.

#include "SpaceShootAbility.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, SpaceShootAbility, "SpaceShootAbility" );
