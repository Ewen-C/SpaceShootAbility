// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Pawn_SSA.h"
#include "PlayerPawn_SSA.generated.h"

/**
 * 
 */
UCLASS()
class SPACESHOOTABILITY_API APlayerPawn_SSA : public APawn_SSA
{
	GENERATED_BODY()
	
};
